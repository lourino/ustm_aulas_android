package com.example.appproject.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.appproject.model.Disciplina;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "app_project_db";
    public static final int DATABASE_VERSION = 1;

    private static final String SQL_CREATE_DISCIPLINA =
            "CREATE TABLE " + DisciplinaContract.DisciplinaEntry.TABLE_NAME + " (" +
                    DisciplinaContract.DisciplinaEntry._ID + " INTEGER PRIMARY KEY," +
                    DisciplinaContract.DisciplinaEntry.NOME + "text, " + DisciplinaContract.DisciplinaEntry.PROFESSOR + "text, " +
                    DisciplinaContract.DisciplinaEntry.CONTACTO_DO_PROFESSOR + "text, " + DisciplinaContract.DisciplinaEntry.DESCRICAO + "text" +
            ")";

    private static final String SQL_CREATE_PAUTA =
            "CREATE TABLE " + PautaContract.PautaEntry.TABLE_NAME + " (" +
                    PautaContract.PautaEntry._ID + "INTEGER PRIMARY KEY, " +
                    PautaContract.PautaEntry.ID_DISCIPLINA + "INTEGER, "
                    + "FOREIGN KEY(id_disciplina) REFERENCES disciplina(id)" + ")";

    private static final String SQL_CREATE_TESTE =
            "CREATE TABLE " + TesteContract.TesteEntry.TABLE_NAME + "(" + TesteContract.TesteEntry._ID
                    + "INTEGER PRIMARY KEY, " + TesteContract.TesteEntry.DESCRICAO + "text, " +
                    TesteContract.TesteEntry.NOTA + "INTEGER, " + TesteContract.TesteEntry.ID_PAUTA +
                    "INTEGER, " + "FOREIGN KEY(id_pauta) REFERENCES pauta(id)" + ")";

    private static final String SQL_DELETE_DISCIPLINA =
            "DROP TABLE IF EXISTS " + DisciplinaContract.DisciplinaEntry.TABLE_NAME;

    private static final String SQL_DELETE_PAUTA =
            "DROP TABLE IF EXISTS " + PautaContract.PautaEntry.TABLE_NAME;

    private static final String SQL_DELETE_TESTE =
            "DROP TABLE IF EXISTS " + TesteContract.TesteEntry.TABLE_NAME;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_CREATE_DISCIPLINA);
        sqLiteDatabase.execSQL(SQL_CREATE_PAUTA);
        sqLiteDatabase.execSQL(SQL_CREATE_TESTE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(SQL_DELETE_DISCIPLINA);
        sqLiteDatabase.execSQL(SQL_DELETE_PAUTA);
        sqLiteDatabase.execSQL(SQL_DELETE_TESTE);
        onCreate(sqLiteDatabase);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
