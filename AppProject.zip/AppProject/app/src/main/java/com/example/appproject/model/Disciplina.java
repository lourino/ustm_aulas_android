package com.example.appproject.model;

public class Disciplina {
    private int id;
    private String nome;
    private String professor;
    private String contactoProfessor;
    private String descricao;
    private Pauta pauta;

    public Disciplina(){

    }

    public Disciplina(String nome, String professor, String contactoProfessor, String descricao){
        this.setNome(nome);
        this.setProfessor(professor);
        this.setContactoProfessor(contactoProfessor);
        this.setDescricao(descricao);
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public String getContactoProfessor() {
        return contactoProfessor;
    }

    public void setContactoProfessor(String contactoProfessor) {
        this.contactoProfessor = contactoProfessor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Pauta getPauta() {
        return pauta;
    }

    public void setPauta(Pauta pauta) {
        this.pauta = pauta;
    }
}
