package com.example.appproject.database;

import android.provider.BaseColumns;

public final class DisciplinaContract {

    private DisciplinaContract(){

    }

    public static class DisciplinaEntry implements BaseColumns {
        public static final String TABLE_NAME = "disciplina";
        public static final String NOME = "nome";
        public static final String PROFESSOR = "professor";
        public static final String CONTACTO_DO_PROFESSOR = "contacto_do_professor";
        public static final String DESCRICAO = "descricao";
    }
}
