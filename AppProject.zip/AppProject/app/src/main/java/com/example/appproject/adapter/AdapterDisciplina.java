package com.example.appproject.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.appproject.NovaDisciplina;
import com.example.appproject.R;
import com.example.appproject.model.Disciplina;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AdapterDisciplina extends RecyclerView.Adapter<AdapterDisciplina.MyViewHolder> {

    private List<String> listaImg;
    private List<Disciplina> listaDisciplinas;
    private List<String> listaprofessores;
    private List<Integer> listamedias;
    private Context mContext;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tvdocenteDisciplina;
        public TextView tvnomeDisciplina;
        public TextView tvmediaDisciplina;
        public CircleImageView imgDisciplina;
        public RelativeLayout parentLayout;

        public MyViewHolder(View view) {
            super(view);
            tvdocenteDisciplina = (TextView) view.findViewById(R.id.tvdocenteDisciplina);
            tvnomeDisciplina = (TextView) view.findViewById(R.id.tvnomeDisciplina);
            tvmediaDisciplina = (TextView) view.findViewById(R.id.tvmediaDisciplina);
            imgDisciplina = view.findViewById(R.id.imgDisciplina);
            parentLayout = view.findViewById(R.id.parent_layout);

            //Metodo para colocar acção no item do RecyclerView
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(null, NovaDisciplina.class);

                }
            });
        }
    }

    public AdapterDisciplina(List<Disciplina> disciplinaList) {
        this.listaDisciplinas = disciplinaList;
    }

    @NonNull
    @Override
    public AdapterDisciplina.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_disciplina, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterDisciplina.MyViewHolder holder, int position) {

        Glide.with(mContext)
                .asBitmap()
                .load(listaImg.get(position))
                .into(holder.imgDisciplina);

        Disciplina movie = listaDisciplinas.get(position);
        holder.tvdocenteDisciplina.setText(movie.getProfessor());
        holder.tvnomeDisciplina.setText(movie.getNome());
        holder.tvmediaDisciplina.setText("Media: ");

        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Passar para o painel Detalhes de disciplina
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaDisciplinas.size();
    }
}
