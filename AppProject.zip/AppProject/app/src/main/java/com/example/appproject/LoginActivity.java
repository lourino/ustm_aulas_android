package com.example.appproject;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private ImageView imgUstm;
    private EditText codigo;
    private EditText senha;
    private Button entrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        imgUstm = (ImageView) findViewById(R.id.imgUstm);
        codigo = (EditText) findViewById(R.id.etCodigo);
        senha = (EditText) findViewById(R.id.etSenha);
        entrar = (Button) findViewById(R.id.btnEntrar);

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validarAcesso(codigo.getText().toString(), senha.getText().toString());
            }
        });
    }

    private void validarAcesso(String codigo, String senha){
        if(codigo == "a" && senha == "b"){
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
        }
        else{
            Toast.makeText(LoginActivity.this, "Acesso negado!", Toast.LENGTH_LONG).show();
        }
    }
}
