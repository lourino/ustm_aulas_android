package com.example.appproject.model;

import java.util.List;

public class Pauta {

    private int id;
    private List<Teste> testes;
    private int idDisciplina;

    public Pauta(){

    }

    public Pauta(List<Teste> testes, int idDisciplina){
        this.setTestes(testes); this.idDisciplina = idDisciplina;
    }

    public double calculaMedia(List<Teste> testes){
        double media = 0;
        for (int i = 0; i < testes.size(); i++) {
            media =+ testes.get(i).getNota();
        }
        return media/testes.size();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Teste> getTestes() {
        return testes;
    }

    public void setTestes(List<Teste> testes) {
        this.testes = testes;
    }

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }
}
