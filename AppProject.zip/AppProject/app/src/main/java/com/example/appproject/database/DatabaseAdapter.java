package com.example.appproject.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.appproject.model.Disciplina;
import com.example.appproject.model.Pauta;
import com.example.appproject.model.Teste;

import java.util.ArrayList;
import java.util.List;

public class DatabaseAdapter {

    DatabaseHelper helper;

    public DatabaseAdapter(Context context) {
        helper = new DatabaseHelper(context);
    }

    public long insertDisciplina(String nome, String professor, String contactoProfessor, String descricao) {
        SQLiteDatabase dbb = helper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DisciplinaContract.DisciplinaEntry.NOME, nome);
        contentValues.put(DisciplinaContract.DisciplinaEntry.PROFESSOR, professor);
        contentValues.put(DisciplinaContract.DisciplinaEntry.CONTACTO_DO_PROFESSOR, contactoProfessor);
        contentValues.put(DisciplinaContract.DisciplinaEntry.DESCRICAO, descricao);
        long id = dbb.insert(DisciplinaContract.DisciplinaEntry.TABLE_NAME, null, contentValues);
        dbb.close();
        return id;
    }

    public List<Disciplina> getDisciplinas() {

        List<Disciplina> disciplinas = new ArrayList<>();
        SQLiteDatabase db = helper.getWritableDatabase();

        //Colunas por ler
        String[] projection = {
                DisciplinaContract.DisciplinaEntry._ID,
                DisciplinaContract.DisciplinaEntry.NOME,
                DisciplinaContract.DisciplinaEntry.PROFESSOR,
                DisciplinaContract.DisciplinaEntry.CONTACTO_DO_PROFESSOR,
                DisciplinaContract.DisciplinaEntry.DESCRICAO
        };
        //Query
        Cursor cursor = db.query(DisciplinaContract.DisciplinaEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);

        while (cursor.moveToNext()) {

            int cid = cursor.getInt(cursor.getColumnIndex(DisciplinaContract.DisciplinaEntry._ID));
            String nome = cursor.getString(cursor.getColumnIndex(DisciplinaContract.DisciplinaEntry.NOME));
            String professor = cursor.getString(cursor.getColumnIndex(DisciplinaContract.DisciplinaEntry.PROFESSOR));
            String contactoProfessor = cursor.getString(cursor.getColumnIndex(DisciplinaContract.DisciplinaEntry.CONTACTO_DO_PROFESSOR));
            String descricao = cursor.getString(cursor.getColumnIndex(DisciplinaContract.DisciplinaEntry.DESCRICAO));

            Disciplina disciplina = new Disciplina();
            disciplina.setId(cid);
            disciplina.setNome(nome);
            disciplina.setProfessor(professor);
            disciplina.setContactoProfessor(contactoProfessor);
            disciplina.setDescricao(descricao);
            disciplinas.add(disciplina);
        }
        return disciplinas;
    }

    public long insertPauta(int idDisciplina) {
        SQLiteDatabase dbb = helper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(PautaContract.PautaEntry.ID_DISCIPLINA, idDisciplina);
        long id = dbb.insert(PautaContract.PautaEntry.TABLE_NAME, null, contentValues);
        dbb.close();
        return id;
    }

    public long insertTeste(String descricao, double nota, int idPauta) {
        SQLiteDatabase dbb = helper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TesteContract.TesteEntry.DESCRICAO, descricao);
        contentValues.put(TesteContract.TesteEntry.NOTA, nota);
        contentValues.put(TesteContract.TesteEntry.ID_PAUTA, idPauta);
        long id = dbb.insert(TesteContract.TesteEntry.TABLE_NAME, null, contentValues);
        dbb.close();
        return id;
    }

    public List<Teste> getTestes() {

        List<Teste> testes = new ArrayList<>();
        SQLiteDatabase db = helper.getWritableDatabase();

        //Colunas por ler
        String[] projection = {
                TesteContract.TesteEntry._ID,
                TesteContract.TesteEntry.DESCRICAO,
                TesteContract.TesteEntry.NOTA,
                TesteContract.TesteEntry.ID_PAUTA,
        };
        //Query
        Cursor cursor = db.query(TesteContract.TesteEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null);

        while (cursor.moveToNext()) {

            int cid = cursor.getInt(cursor.getColumnIndex(TesteContract.TesteEntry._ID));
            String descricao = cursor.getString(cursor.getColumnIndex(TesteContract.TesteEntry.DESCRICAO));
            Double nota = cursor.getDouble(cursor.getColumnIndex(TesteContract.TesteEntry.NOTA));
            Integer id_pauta = cursor.getInt(cursor.getColumnIndex(TesteContract.TesteEntry.ID_PAUTA));

            Teste teste = new Teste();
            teste.setId(cid);
            teste.setDescricao(descricao);
            teste.setNota(nota);
            teste.setIdPauta(id_pauta);
            testes.add(teste);
        }
        return testes;
    }
}
