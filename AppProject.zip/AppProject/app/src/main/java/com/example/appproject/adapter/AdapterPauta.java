package com.example.appproject.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.appproject.R;
import com.example.appproject.model.Pauta;

import java.util.List;

public class AdapterPauta extends RecyclerView.Adapter<AdapterPauta.MyViewHolder> {

    private List<Pauta> pautaList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTeste;

        public MyViewHolder(View view) {
            super(view);
            tvTeste = (TextView) view.findViewById(R.id.info_text);
        }
    }

    public AdapterPauta(List<Pauta> pautaList) {
        this.pautaList = pautaList;
    }



    @NonNull
    @Override
    public AdapterPauta.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_teste, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterPauta.MyViewHolder holder, int position) {
        Pauta pauta = pautaList.get(position);
        for (int j = 0; j < pauta.getTestes().size(); j++) {
            holder.tvTeste.setText(pauta.getTestes().get(j).getNota().toString());
        }
    }

    @Override
    public int getItemCount() {
        return pautaList.size();
    }
}
