package com.example.appproject.database;

import android.provider.BaseColumns;

public class PautaContract {

    public PautaContract(){

    }

    public static class PautaEntry implements BaseColumns {
        public static final String TABLE_NAME = "pauta";
        public static final String ID_DISCIPLINA = "id_disciplina";
    }
}
