package com.example.appproject.model;

public class Teste {
    private int id;
    private String descricao;
    private Double nota;
    private Integer idPauta;

    public Teste(){

    }

    public Teste(String descricao, Double nota){
        this.setDescricao(descricao);
        this.setNota(nota);
    }


    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        this.nota = nota;
    }

    public int getIdPauta() {
        return idPauta;
    }

    public void setIdPauta(Integer idPauta) {
        this.idPauta = idPauta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
