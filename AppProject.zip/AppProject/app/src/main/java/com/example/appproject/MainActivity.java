package com.example.appproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.example.appproject.adapter.AdapterDisciplina;
import com.example.appproject.database.DatabaseAdapter;
import com.example.appproject.model.Disciplina;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private List<String> listaImg;
    private List<Disciplina> listaDisciplinas;
    private List<String> listaprofessores;
    private List<Integer> listamedias;
    private RecyclerView rvDisciplina;
    private RecyclerView.LayoutManager layoutManager;
    private AdapterDisciplina mAdapterDisciplina;

    private List<Disciplina> disciplinasList = new ArrayList<>();

    private double valor;

    DatabaseAdapter helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        helper = new DatabaseAdapter(getApplicationContext());

        Intent i =this.getIntent();

        rvDisciplina = (RecyclerView) findViewById(R.id.rvDisciplina);
        rvDisciplina.setHasFixedSize(true);
        rvDisciplina.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        layoutManager = new LinearLayoutManager(this);
        rvDisciplina.setLayoutManager(layoutManager);

        disciplinasList.addAll(helper.getDisciplinas());
        mAdapterDisciplina = new AdapterDisciplina(disciplinasList);

        rvDisciplina.setAdapter(mAdapterDisciplina);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, NovaDisciplina.class));
            }
        });
    }
}
