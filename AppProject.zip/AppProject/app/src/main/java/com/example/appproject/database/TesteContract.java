package com.example.appproject.database;

import android.provider.BaseColumns;

public class TesteContract {

    private TesteContract(){

    }

    public static class TesteEntry implements BaseColumns {
        public static final String TABLE_NAME = "teste";
        public static final String DESCRICAO = "descricao";
        public static final String NOTA = "nota";
        public static final String ID_PAUTA = "id_pauta";
    }
}
