package com.example.appproject;

import android.os.Bundle;

import com.example.appproject.database.DatabaseAdapter;
import com.google.android.material.textfield.TextInputEditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NovaDisciplina extends AppCompatActivity {

    private EditText etNomeDisciplina;
    private EditText etProfessor;
    private EditText etContactoProfessor;
    private TextInputEditText tietDescricao;
    private Button btnAdicionarDisciplina;

    DatabaseAdapter helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_disciplina);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Inicializar a classe AdapterDisciplina da BD
        helper = new DatabaseAdapter(getApplicationContext());

        etNomeDisciplina = (EditText) findViewById(R.id.etNomeDisciplina);
        etProfessor = (EditText) findViewById(R.id.etProfessor);
        etContactoProfessor = (EditText) findViewById(R.id.etContactoProfessor);
        tietDescricao = (TextInputEditText) findViewById(R.id.tiedDescricao);
        btnAdicionarDisciplina = (Button) findViewById(R.id.btnAdicionarDisciplina);

        btnAdicionarDisciplina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Adicionar na base de dados
                String nomeDisciplina = etNomeDisciplina.getText().toString();
                String professor = etProfessor.getText().toString();
                String contactoProfessor = etContactoProfessor.getText().toString();
                String descricao = tietDescricao.getText().toString();

                long id = helper.insertDisciplina(nomeDisciplina, professor, contactoProfessor, descricao);

            }
        });
    }

}
